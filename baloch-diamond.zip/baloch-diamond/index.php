<?php
/**
 * The main template file — fallback
 *
 * WordPress uses this when no more specific template matches.
 * For the blog archive, home.php takes priority when is_home() is true.
 * For category/tag/date archives, archive.php takes priority.
 *
 * This file handles any remaining edge cases (e.g. sitemap queries).
 *
 * @package Baloch_Diamond
 * @version 1.2.2
 */

get_header();
?>

<main class="site-main" id="mainContent">

    <?php if ( is_home() && ! is_front_page() ) : ?>
        <!-- Blog index fallback (home.php should handle this, but just in case) -->
        <?php get_template_part( 'template-parts/hero-slider' ); ?>
    <?php else : ?>
        <div style="margin-top:70px"></div>
    <?php endif; ?>

    <!-- Page Header -->
    <div class="section" style="padding-bottom:30px">
        <div class="section-header">
            <div class="section-badge">
                <?php echo bd_icon( 'file-text', 16, 16 ); ?>
                <?php esc_html_e( 'Blog', 'baloch-diamond' ); ?>
            </div>
            <h1 class="section-title">
                <?php
                if ( is_home() && ! is_front_page() ) {
                    single_post_title();
                } else {
                    esc_html_e( 'Latest Posts', 'baloch-diamond' );
                }
                ?>
            </h1>
        </div>
    </div>

    <!-- Posts Grid -->
    <div class="section" style="padding-top:0">
        <?php if ( have_posts() ) : ?>

            <div class="posts-grid">
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php get_template_part( 'template-parts/content' ); ?>
                <?php endwhile; ?>
            </div>

            <?php
            the_posts_pagination( array(
                'mid_size'  => 2,
                'prev_text' => bd_icon( 'arrow-left', 16, 16 ) . ' <span class="nav-prev-text">' . esc_html__( 'Newer', 'baloch-diamond' ) . '</span>',
                'next_text' => '<span class="nav-next-text">' . esc_html__( 'Older', 'baloch-diamond' ) . '</span> ' . bd_icon( 'arrow-right', 16, 16 ),
            ) );
            ?>

        <?php else : ?>

            <div class="error-404" style="padding:40px 24px">
                <div class="error-diamond" style="width:40px;height:40px"></div>
                <h2 class="error-title" style="font-size:1.5rem"><?php esc_html_e( 'No Posts Found', 'baloch-diamond' ); ?></h2>
                <p class="error-desc" style="font-size:1rem">
                    <?php esc_html_e( 'It seems we can\'t find what you\'re looking for. Perhaps searching can help.', 'baloch-diamond' ); ?>
                </p>
                <div class="error-buttons">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn-gradient">
                        <?php echo bd_icon( 'home', 18, 18 ); ?>
                        <?php esc_html_e( 'Back to Home', 'baloch-diamond' ); ?>
                    </a>
                </div>
            </div>

        <?php endif; ?>
    </div>

</main>

<?php
get_footer();
